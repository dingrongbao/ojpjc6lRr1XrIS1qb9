screen -dmS q  numactl --cpubind=0 --membind=0  ./nostr
